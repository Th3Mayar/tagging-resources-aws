# `tagging-aws-resources` – AWS Resource Tagging Tool

**The definitive, enterprise-grade tagging solution**  
EC2 Instances · EBS Volumes · Snapshots · EFS · All FSx types · Cost Allocation Tags activation  

## Overview & Capabilities (v0.1.4)

| Feature                              | Description                                                                                          | Command example                                    |
|--------------------------------------|------------------------------------------------------------------------------------------------------|----------------------------------------------------|
| Full EC2 lineage tagging             | Instances → Volumes → Snapshots (including AMI/CreateImage snapshots)                                 | `tagging all --apply`                              |
| Orphaned AMI snapshot recovery       | Fixes snapshots from terminated instances (even years old)                                           | `tagging all --fix-orphans --apply`                |
| EFS + All FSx types                  | FileSystems, Access Points, Volumes, SVMs, Backups, File Caches                                       | `tagging all --tag-storage --apply`               |
| Cost Allocation Tags activation      | NEW: `tagging activate` → enables tags in Cost Explorer (global or per region)                      | `tagging activate --apply`                         |
| 100% read-only by default            | No `--apply` = DRY-RUN (safe to run 1000 times)                                                      | `tagging all` (preview only)                       |
| Unified CLI with Linux-style syntax  | `all`, `set`, `dry-run`, `show`, `activate`                                                          | `tagging set us-east-1 --apply --tag-storage`      |
| Professional output                  | Clear [PLAN]/[APPLY] logs, region summaries, error handling                                          | All commands                                       |

## CLI Model & Default Behavior

**Command:** `tagging`  
**DRY-RUN by default** for all actions.  
Real changes happen **only** when `--apply` is explicitly provided.

### Supported Commands

| Command                          | Description                                                                 | Example                                      |
|----------------------------------|-----------------------------------------------------------------------------|----------------------------------------------|
| `tagging all`                    | Tag all regions (dry-run by default)                                        | `tagging all`                                |
| `tagging all --apply`            | Real tagging in all regions                                                 | `tagging all --apply`                        |
| `tagging set <region>`           | Tag one region (dry-run)                                                    | `tagging set us-east-1`                      |
| `tagging set <region> --apply`   | Real tagging in one region                                                  | `tagging set us-east-1 --apply`              |
| `tagging dry-run [<region>]`     | Force dry-run (all or one region)                                           | `tagging dry-run eu-west-1`                  |
| `tagging show [<region>]`        | Show resources only (no tagging)                                            | `tagging show`                               |
| `tagging activate`               | Activate Cost Allocation Tags (dry-run)                                     | `tagging activate`                           |
| `tagging activate --apply`       | Activate Cost Allocation Tags globally                                      | `tagging activate --apply`                   |
| `tagging activate <region> --apply` | Activate Cost Allocation Tags in one region                              | `tagging activate us-east-1 --apply`         |

### Flags

| Flag              | Description                                                              |
|-------------------|--------------------------------------------------------------------------|
| `--apply`         | Apply real changes (required for any modification)                      |
| `--tag-storage`   | Also tag EFS + all FSx types (FileSystems, Volumes, Backups, SVMs, etc.)|
| `--fix-orphans`   | Only fix orphaned AMI snapshots (no regular tagging)                    |

## Required IAM Permissions (minimum)

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ec2:DescribeInstances",
        "ec2:DescribeVolumes",
        "ec2:DescribeSnapshots",
        "ec2:DescribeImages",
        "ec2:DescribeRegions",
        "ec2:DescribeTags",
        "ec2:CreateTags",
        "elasticfilesystem:*",
        "fsx:*",
        "ce:ListCostAllocationTags",
        "ce:PutCostAllocationTags"
      ],
      "Resource": "*"
    }
  ]
}
```

## Installation (Linux – APT repository)

### One-line installation (recommended)

```bash
echo "deb [trusted=yes] https://th3mayar.github.io/tagging-resources-aws/apt ./" | sudo tee /etc/apt/sources.list.d/tagging-resources-aws.list
sudo apt update
sudo apt install tagging-resources-aws bash-completion
```

### Bash completion activation (required on some systems)

The package installs completion, but some environments (especially WSL + Ubuntu) don't load it automatically.

Add this to your `~/.bashrc` or `~/.zshrc`:

```bash
if ! shopt -oq posix; then
  if [ -f /usr/share/bash-completion/bash_completion ]; then
    . /usr/share/bash-completion/bash_completion
  elif [ -f /etc/bash_completion ]; then
    . /etc/bash_completion
  fi
fi
```

Then reload:
```bash
source ~/.bashrc
```

Now you get full TAB completion:
```bash
tagging s<TAB>        → set / show
tagging se<TAB>       → set
tagging all --<TAB>   → --apply --tag-storage --fix-orphans
tagging set us-<TAB>  → us-east-1 us-east-2 ...
```

## Safety & Production Features

- **Dry-run by default** – impossible to accidentally modify anything
- **100% idempotent** – safe for daily EventBridge/Lambda execution
- **Never overwrites existing tags**
- **Skips terminated instances**
- **Fully compatible** with Auto Scaling Groups, CloudFormation, Launch Templates
- **Clear [PLAN]/[APPLY] output** – you always know exactly what will happen
- **Cost Allocation Tags activation** – `tagging activate --apply` makes your tags visible in Cost Explorer

## Recommended Corporate Usage

| Frequency       | Command                                              | Notes                                          |
|-----------------|------------------------------------------------------|------------------------------------------------|
| Daily           | `tagging all --tag-storage --apply`                 | Full lineage + storage tagging                 |
| Daily + Tags    | `tagging activate --apply`                           | Keep Cost Allocation Tags up to date           |
| Weekly          | `tagging all --fix-orphans --apply`                  | Clean orphaned AMI snapshots                   |
| Initial rollout | `tagging all` → review → `tagging all --apply`       | Always validate dry-run first                  |

## Release Notes v0.1.4 (21 Nov 2025)

- NEW: `tagging activate` – activate Cost Allocation Tags (global or per region)
- NEW: Full APT repository + bash completion
- FIXED: EFS Mount Targets tagging (now 100% reliable)
- IMPROVED: Professional output, better error handling
- UPDATED: Fully compatible with Q Developer CLI 2025